void GPS(UART_HandleTypeDef *huart2);
double lat_Parse();
double long_Parse();
